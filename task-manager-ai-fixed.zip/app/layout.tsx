export const metadata = {
  title: "AI Task Manager",
  description: "Your personal AI multi-threaded task assistant",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-white text-gray-900">{children}</body>
    </html>
  );
}