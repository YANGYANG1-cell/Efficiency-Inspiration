export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">AI 任务管理系统</h1>
      <p className="text-lg text-center max-w-xl">
        欢迎使用你的多线程生活助理原型系统！你可以在这里整合任务、拆解步骤并接入未来的 AI 自动处理器。
      </p>
    </main>
  );
}