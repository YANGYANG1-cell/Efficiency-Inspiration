"use client";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

export default function TaskManager() {
  const [taskInput, setTaskInput] = useState("");
  const [tasks, setTasks] = useState([]);

  const handleAddTask = () => {
    if (!taskInput.trim()) return;
    const newTask = {
      id: Date.now(),
      content: taskInput,
      subtasks: [`分析任务：“${taskInput}”`, "AI生成子任务1", "AI生成子任务2"],
      status: "未开始",
    };
    setTasks([newTask, ...tasks]);
    setTaskInput("");
  };

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-4">
      <h1 className="text-3xl font-bold">🧠 AI 多线程任务助手</h1>
      <div className="flex space-x-2">
        <Input
          placeholder="输入一句任务，如“整理会员卡”"
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
        />
        <Button onClick={handleAddTask}>➕ 添加任务</Button>
      </div>

      <div className="grid gap-4">
        {tasks.map((task) => (
          <motion.div
            key={task.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="space-y-2 p-4">
                <div className="text-lg font-medium">📝 {task.content}</div>
                <div className="space-y-1">
                  {task.subtasks.map((sub, idx) => (
                    <div key={idx} className="text-sm text-gray-600">
                      ✅ {sub}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}