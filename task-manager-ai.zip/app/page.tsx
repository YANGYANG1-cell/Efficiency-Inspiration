'use client';
import TaskManager from '../components/TaskManager';

export default function Home() {
  return <TaskManager />;
}